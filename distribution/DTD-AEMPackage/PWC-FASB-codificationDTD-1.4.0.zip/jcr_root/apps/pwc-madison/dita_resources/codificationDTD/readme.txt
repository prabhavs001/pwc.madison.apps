Readme for com.asc.doctypes
---------------------------

19 June, 2019 (Jake Campbell, Scriptorium
------------------
*Added the content-id element to the asc-prolog and subsect-prolog elements.
    *content-id inherits from the source element and contains text

3 July 2018 (Simon Bate, Scriptorium) 
------------------
* Made asc DITA compliant, including removing <xref-PDF>, <xref-external>, <xref-notUsed>, <xref-codUpdate> and <xref-grandfathered>.
* Made href a required attribute of <xref>

26 July 2018 (Simon Bate, Scriptorium) 
------------------
* Integrated updated DTD from FAF, including <pending-content-parameters> and child elements.

8 August 2018 (Simon Bate, Scriptorium) 
------------------
* Added <pnum-citation> element, per Propylon. 

25 September 2018
------------------
* Created as a DITA-OT plug-in

