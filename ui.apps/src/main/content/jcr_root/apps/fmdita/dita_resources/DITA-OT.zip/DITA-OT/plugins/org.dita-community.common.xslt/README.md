org.dita-community.common.xslt
==============================

Basic support XSLT libraries useful for any XSLT transform: relpath_utils.xsl and dita-support-lib.xsl. Intended for use with the DITA Open Toolkit but not limited to that use.

